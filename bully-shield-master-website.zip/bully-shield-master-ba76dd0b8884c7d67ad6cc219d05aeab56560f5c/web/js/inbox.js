$(document).ready(function() {
    var table = $('#inbox').dataTable({
        /* No ordering applied by DataTables during initialisation */
        "order": []
    });
});