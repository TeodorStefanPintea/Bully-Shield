def p():
  print "Rewrite the code!"
